# ScriptableRendererFeature Example
A barebones example of Unity's ScriptableRendererFeature for use in scriptable render pipelines.

Created for Unity 2019.3, but it should continue to work in future versions. The example feature inverts all the colours in the rendered scene. It's not intended to be a useful feature on its own, but should provide a starting off point for building something.

You might like to see [a short tutorial](https://samdriver.xyz/articles/scriptableRender.htm) I wrote alongside this.
